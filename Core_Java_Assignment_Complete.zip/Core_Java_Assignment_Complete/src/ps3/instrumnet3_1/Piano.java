package ps3.instrumnet3_1;

public class Piano extends Instrument {

	@Override
	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");

	}

}

